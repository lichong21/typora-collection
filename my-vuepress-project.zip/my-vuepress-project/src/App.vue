<template>
  <div id="app">
    <router-link to="/sort/bubble">冒泡</router-link>
    ---
    <router-link to="/sort/insert">插入</router-link>
    <hr>
    <router-view/>
  </div>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
