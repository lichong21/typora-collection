import Vue from 'vue';
import VueRouter, { RouteConfig } from 'vue-router';

Vue.use(VueRouter);

const routes: Array<RouteConfig> = [
  {
    path: '/',
    redirect: '/sort',
  },
  {
    path: '/sort',
    redirect: '/sort/bubble',
  },
  {
    path: '/sort/bubble',
    component: () => import('@/views/sort-collection/BubbleSort.vue')
  },
  {
    path: '/sort/insert',
    component: () => import('../views/sort-collection/InsertSort.vue')
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
