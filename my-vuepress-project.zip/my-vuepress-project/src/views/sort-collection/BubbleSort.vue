<template>
  <div>
    <h1>毛包富海大厦空间</h1>
    <el-button>默认按钮</el-button>
    <el-button type="primary">主要按钮</el-button>
    <el-button type="success">成功按钮</el-button>
    <el-button type="danger">危险按钮</el-button>
  </div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator';

@Component
export default class BubbleSort extends Vue {
  name = 'dasda';
}
</script>
<style lang="scss" scoped>
</style>
