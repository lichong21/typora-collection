<template>
  <div>
    <h1>fhdsijk的还是把接口</h1>
    {{ name }}
  </div>
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator';

@Component
export default class InsertSort extends Vue {
  name = 123213;
}
</script>
<style lang="scss" scoped>

</style>
